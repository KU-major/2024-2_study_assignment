public struct MoveInfo
{
    public int dirX;
    public int dirY;
    public int distance;

    public MoveInfo(int dirX, int dirY, int distance)
    {
        this.dirX = dirX;
        this.dirY = dirY;
        this.distance = distance;
    }
}
